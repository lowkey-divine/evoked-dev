# Disclaimer

This kit is free educational material from Evoked, provided for learning and experimentation.

It is NOT legal, security, compliance, or professional advice.

The kit is provided "AS IS", without warranty of any kind, express or implied, including
but not limited to the warranties of merchantability, fitness for a particular purpose,
and non-infringement.

The scripts in this kit (including demo.sh, refuse.sh, drift-check.sh, and demo-drift.sh)
are illustrative teaching examples. They are not a security control, a safety mechanism,
or production-ready software. Do not rely on them to protect any system, data, or person.
Review any script before you run it, and run it at your own risk.

To the maximum extent permitted by law, Evoked and Erin Stanley are not liable for any
loss, damage, breach, or harm arising from the use of this material.

Using this kit does not create any advisory, consulting, or professional relationship.
For a real engagement, see https://evoked.dev.
