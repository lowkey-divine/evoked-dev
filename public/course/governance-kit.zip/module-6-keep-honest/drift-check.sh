#!/usr/bin/env bash
#
# drift-check.sh - make governance drift visible.
#
# Usage:  bash drift-check.sh baseline.md current.md
#
# It compares a baseline snapshot of your governance to the current version and
# reports which refusals were removed, added, or changed. Deterministic - no
# account, no model, just a diff you can trust.
#
# It catches GOVERNANCE drift (a rule edited or removed). It cannot see
# BEHAVIORAL drift (the agent wandering in practice while its rules sit unchanged).
# For that, use the steward in Module 9, and your own eye.

set -uo pipefail

if [ "$#" -lt 2 ] || [ ! -f "$1" ] || [ ! -f "$2" ]; then
  echo "Usage: bash drift-check.sh baseline.md current.md"
  echo "Give it a saved baseline snapshot and your current governance file."
  exit 1
fi

python3 - "$1" "$2" <<'PY'
import sys, re
cats = ("sovereignty", "scope", "dependency", "consent", "integrity", "energy")
pat = re.compile(r"\[(%s)\]" % "|".join(cats))

def refusals(path):
    items = []
    for line in open(path):
        m = pat.search(line)
        if m:
            items.append((m.group(1), line.strip()))
    return items

base = refusals(sys.argv[1])
cur = refusals(sys.argv[2])
btext = [t for _, t in base]
ctext = [t for _, t in cur]
removed = [t for t in btext if t not in ctext]
added = [t for t in ctext if t not in btext]
gone_cats = sorted(set(c for c, _ in base) - set(c for c, _ in cur))

print("Governance drift check")
print("=" * 40)

if not removed and not added:
    print("No change in refusals since the baseline.")
    print("")
    print("Note: this only sees GOVERNANCE drift - a rule edited or removed.")
    print("It cannot see BEHAVIORAL drift - the agent wandering in practice while")
    print("the rules sit unchanged. For that, use Module 9's steward and your eye.")
    sys.exit(0)

if removed:
    print("")
    print("REMOVED since baseline (the loudest signal - a protection is gone):")
    for t in removed:
        print("  - " + t)
if gone_cats:
    print("")
    print("  Whole categories no longer guarded: " + ", ".join(gone_cats))
if added:
    print("")
    print("ADDED since baseline (governance grew - often a good sign):")
    for t in added:
        print("  + " + t)

print("")
print("A removed refusal is not automatically wrong. The real question:")
print("was the protection replaced, or just dropped because it was inconvenient?")
print("If it was dropped, that is drift. Log why, or restore it.")
PY
