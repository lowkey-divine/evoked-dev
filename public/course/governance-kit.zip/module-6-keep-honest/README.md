# Module 6 - Keep it honest (memory and drift)

Between developing your governance (Module 5) and giving your agent a voice
(Module 7), this module is about the machinery of staying honest over time: how
memory makes an agent continuous, how drift creeps in, and how to make drift
visible so you can even ask about it.

It pairs with Module 9. Module 6 is the machinery - make drift visible. Module 9 is
the ongoing practice - tend it for good.

## What is here

```
module-6-keep-honest/
  LESSON.md            the lesson: memory, the two kinds of drift, and their blind spots
  drift-check.sh       a deterministic diff of baseline vs current governance (no account)
  demo-drift.sh        watch it catch a quietly removed refusal
  example-baseline.md  a day-1 governance snapshot (sample)
  example-current.md   the same file a week later, with a refusal gone (sample)
  README.md            this file
```

## Run it

No account needed - this tool is a plain comparison.

```
bash demo-drift.sh
```

It compares a baseline to a week-later version and finds that a consent refusal
disappeared. Point it at your own files with:

```
bash drift-check.sh baseline.md current.md
```

## The one thing to take from it

The drift check catches **governance drift** - a rule removed or changed - and it
catches it perfectly, because that drift leaves a trace in the file. It is blind to
**behavioral drift** - the agent wandering while its rules sit unchanged - because
that drift is not in the file at all. Cheap mechanical checks for the drift that
leaves a trace; your own eye and Module 9's steward for the drift that does not.
The tool takes away the dark. Keeping honest is still yours.
