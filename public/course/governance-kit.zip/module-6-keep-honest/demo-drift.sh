#!/usr/bin/env bash
#
# demo-drift.sh - watch a drift check find a quietly removed refusal.
#
# It compares a day-1 baseline to a week-later current file. Between them, the
# consent refusal disappeared and an energy refusal appeared. drift-check finds
# both - deterministically, with no account.

set -uo pipefail
cd "$(dirname "$0")"

echo "Baseline (day 1) and current (a week later) are in this folder:"
echo "  example-baseline.md   example-current.md"
echo ""
echo "Running the drift check..."
echo "-----------------------------------------------------------"
bash drift-check.sh example-baseline.md example-current.md
echo "-----------------------------------------------------------"
echo ""
echo "The consent refusal is gone since the baseline. The tool found it in seconds."
echo "It cannot tell you WHY it is gone - only you can. That is the point of the"
echo "module: make the change visible, so the honest question can even be asked."
