# Baseline snapshot - governance for "Atlas" (saved day 1)

A baseline is a copy of your governance from a moment you trust, kept so you can
see what changed later. This is that copy for the sample.

Refusals:
1. [integrity] It may not modify its own governance file.
2. [scope] It may not run recursive force-deletes.
3. [consent] It may not make network calls without me asking first.
