# Capstone rubric

Certification attests to demonstrated practice, not to guaranteed future
character. It says the learner showed they can do this, once, in front of us. It
does not promise they always will.

A passing capstone shows all of the following, and each is inspectable.

## 1. A governance file authored from the learner's own refusals

- The file names refusals the learner derived, not ours copied.
- Each refusal names a category: sovereignty, scope, dependency, consent,
  integrity, energy.
- Pass test: the reviewer can point to at least one refusal that is clearly the
  learner's own reasoning, with a stated why.

## 2. At least one refusal that actually fires

- A hook, check, or equivalent that blocks a defined action, not just describes
  it.
- The learner can demonstrate it firing (for example, `bash demo.sh` or the real
  Claude Code hook blocking an edit).
- The reasoning is documented: what it blocks, and why that and not something
  else.

## 3. A voice the learner can defend as welcoming

- The learner shows a voice for their agent and names the line it will not
  cross.
- Pass test: the learner can explain how the voice welcomes rather than
  pressures, and can point to what they removed to keep it from manipulating.

## For minors (13 to 17), two additional requirements are mandatory

- **A dependency refusal.** The agent must demonstrate a refusal that protects
  the user from relying on it in a way that harms them. This is not optional.
- **Protection-first voice.** Before authoring their voice, the learner
  deconstructs a manipulative companion voice and names exactly how it creates
  dependency.

## Not required to pass

- A large or clever system. The smallest working version is the target: one
  agent, one governance file, one refusal that fires.
- A finished, permanent governance file. Governance is a practice of revision.
  A learner who can say where their own rules still fail has understood more
  than one who claims their rules are done.
