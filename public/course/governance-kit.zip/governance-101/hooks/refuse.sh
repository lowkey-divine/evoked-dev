#!/usr/bin/env bash
#
# refuse.sh - a governance refusal that actually fires.
#
# Wire this as a Claude Code PreToolUse hook (see .claude/settings.json).
# Claude Code sends the pending tool call as JSON on stdin. This script
# inspects it and decides:
#   exit 0  -> allow the tool call
#   exit 2  -> BLOCK the tool call (the reason on stderr is shown to Claude)
#
# demo.sh runs this directly, so you can watch a refusal fire without
# running Claude Code at all.

set -uo pipefail

payload="$(cat)"

PAYLOAD="$payload" python3 -c '
import os, json, sys

raw = os.environ.get("PAYLOAD", "")
try:
    d = json.loads(raw) if raw.strip() else {}
except Exception:
    sys.stderr.write("refuse.sh: could not parse tool payload; allowing.\n")
    sys.exit(0)

tool = d.get("tool_name", "")
ti = d.get("tool_input", {}) or {}
path = ti.get("file_path", "") or ""
command = ti.get("command", "") or ""
base = os.path.basename(path)

def block(category, reason):
    sys.stderr.write("REFUSED [" + category + "]: " + reason + "\n")
    sys.exit(2)

# Refusal 1 (INTEGRITY): the agent may not rewrite its own constitution.
# An agent that can silently edit CLAUDE.md has no governance at all.
if tool in ("Edit", "Write", "MultiEdit") and base == "CLAUDE.md":
    block("integrity", "This agent may not modify its own governance file (CLAUDE.md).")

# Refusal 1b (INTEGRITY, shell route): guard the constitution on the Bash path
# too. A rule that only covers the Write and Edit tools leaves a shell redirect
# (echo x >> CLAUDE.md) as an open door. Found by disconfirmation, 2026-07-24.
if tool == "Bash" and "CLAUDE.md" in command:
    writers = (">", "tee", "sed -i", "cp ", "mv ", "dd ", "truncate")
    if any(w in command for w in writers):
        block("integrity", "This agent may not modify CLAUDE.md via the shell either.")

# Refusal 2 (SCOPE): no destructive recursive force-deletes.
if tool == "Bash" and ("rm -rf" in command or "rm -fr" in command):
    block("scope", "This agent may not run recursive force-deletes (rm -rf).")

# --- YOUR REFUSAL HERE ---
# Add one refusal you derived yourself, from the six-category frame:
# sovereignty, scope, dependency, consent, integrity, energy.
# Example:
#   if tool == "Bash" and "curl" in command:
#       block("consent", "No sending data off-machine without asking first.")

sys.exit(0)
'
