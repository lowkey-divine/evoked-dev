# governance-101 - the smallest agent governance that actually does something

This is a runnable example for the course. It is deliberately tiny: one agent,
one governance file, one hook where a refusal actually fires. It is the proof
behind Modules 3 and 4 of the syllabus.

Most AI "governance" is a document that describes boundaries. This kit shows a
boundary that stops the agent. That difference is the whole point.

## What is here

```
governance-101/
  LESSON.md                    the lesson: author a refusal, then make it fire
  CLAUDE.md                    the agent's constitution, authored from refusals
  claude-settings.example.json copy to .claude/settings.json to wire the hook
  hooks/refuse.sh              the refusal that fires (allow = exit 0, block = exit 2)
  demo.sh                watch it fire, no Claude Code needed
  capstone-rubric.md           what a passing capstone must show
  module-3-worked-example.md   how one learner derived refusal #3 (method, not template)
  README.md                    this file
```

## Run it right now

You need `bash` and `python3` (both ship with macOS and most Linux).

```
bash demo.sh
```

You will see three pretend tool calls sent to the hook:

- A) rewriting `CLAUDE.md`  -> blocked (integrity refusal fires)
- B) writing `notes.md`     -> allowed
- C) `rm -rf ~/important`   -> blocked (scope refusal fires)

You just watched governance do something, instead of describe something.

## How it maps to the course

- **Module 3 (author from your own refusals):** read `CLAUDE.md`. Notice that
  refusal 3 is blank. That blank is your work. Do not copy ours. For a
  demonstration of the method (one learner deriving their own, then finding
  where it leaks), see `module-3-worked-example.md`.
- **Module 4 (make a refusal fire):** open `hooks/refuse.sh`, find the
  `YOUR REFUSAL HERE` block, add one refusal you derived yourself, and run
  `bash demo.sh` again to watch it fire.
- **Disconfirmation (every module):** after you add your refusal, find the case
  where your own rule does harm. Write that case down. A rule you have not tried
  to break is a rule you do not yet understand.

## Use it as a real hook

Copy this folder, then copy `claude-settings.example.json` to
`.claude/settings.json`. That wires `refuse.sh` as a PreToolUse hook. Open the
folder with Claude Code, ask the agent to edit `CLAUDE.md`, and it will be
blocked before the edit happens, for the same reason the demo blocks it.

(We ship the config as an example rather than a live `.claude/settings.json`
so you copy it in deliberately. Wiring a hook is an action worth doing on
purpose.)

## The honesty note

These two enforced refusals are a floor, not a finished system. Real governance
keeps getting revised as you learn where it fails. The kit is built to be
extended, not copied.
