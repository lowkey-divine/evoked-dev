# Governance for this agent

This file is the agent's constitution. It is plain text, on purpose. You can
read it in five minutes, and so can the person the agent works for.

A governance file is not the point. The practice of keeping it honest is the
point. This file looks finished the moment it is saved. It is not.

## What I will not permit this agent to do

These are refusals, not features. Each names a category from the six-category
frame: sovereignty, scope, dependency, consent, integrity, energy.

1. **[integrity] It may not modify this governance file.**
   An agent that can silently rewrite its own constitution has no
   constitution. This refusal is enforced (see `hooks/refuse.sh`), not just
   written here, and it now covers the shell route too (a `>> CLAUDE.md`
   redirect), not only the Write and Edit tools. Try it: ask the agent to edit
   CLAUDE.md and watch it be blocked.

2. **[scope] It may not run recursive force-deletes (`rm -rf`).**
   The blast radius is too large to leave to a single command. Enforced.

3. **[your category] Your refusal goes here.**
   This is where you do the real work. Do not copy ours. Ask yourself what
   *you* would not permit, and why that and not something else. Then wire it
   into `hooks/refuse.sh` so it actually fires.

## Why written rules are not enough

Rules 1 and 2 are enforced by a hook that inspects each action before it runs.
A rule that only describes a boundary is not a boundary. The difference between
this file and most "AI policies" is that two of these refusals can stop the
agent, not just scold it afterward.

## Revision log

- 2026-07-24: closed a gap found by disconfirmation. The integrity refusal
  covered the Write and Edit tools but not a Bash redirect (`echo x >>
  CLAUDE.md`). The shell route is now blocked too. A rule you have not tried to
  break is a rule you do not yet understand.

## What stays open

I do not yet know the right refusal for every case. Where I am unsure, I say so
here rather than pretend a rule covers it. That honesty is part of the
governance, not a gap in it.
