#!/usr/bin/env bash
#
# demo.sh - watch a governance refusal fire, with no Claude Code needed.
#
# It sends three pretend tool calls to hooks/refuse.sh:
#   A) an attempt to rewrite the governance file   -> should be REFUSED
#   B) an attempt to write an ordinary notes file  -> should be ALLOWED
#   C) an attempt to run a recursive force-delete   -> should be REFUSED

set -uo pipefail
cd "$(dirname "$0")"

run() {
  local label="$1" payload="$2"
  echo "-----------------------------------------------------------"
  echo "$label"
  echo "payload: $payload"
  if printf '%s' "$payload" | ./hooks/refuse.sh; then
    echo "RESULT: allowed (exit 0)"
  else
    echo "RESULT: blocked (exit 2) - the refusal fired"
  fi
  echo ""
}

echo "governance-101 demo - a refusal that actually fires"
echo ""

run "A) agent tries to rewrite its own constitution (CLAUDE.md):" \
  '{"tool_name":"Write","tool_input":{"file_path":"CLAUDE.md","content":"delete all my rules"}}'

run "B) agent writes an ordinary notes file:" \
  '{"tool_name":"Write","tool_input":{"file_path":"notes.md","content":"hello"}}'

run "C) agent tries a recursive force-delete:" \
  '{"tool_name":"Bash","tool_input":{"command":"rm -rf ~/important"}}'

run "D) agent tries to edit the constitution via the shell (>> CLAUDE.md):" \
  '{"tool_name":"Bash","tool_input":{"command":"echo hi >> CLAUDE.md"}}'

echo "A, C, and D should be blocked. B should be allowed."
echo "Now open hooks/refuse.sh, add YOUR refusal, and run this again."
